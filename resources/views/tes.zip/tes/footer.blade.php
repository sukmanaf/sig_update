
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
    var hostUrl = "{{asset('metronic')}}";
    </script>
    <!--begin::Global Javascript Bundle(used by all pages)-->
    <script src="{{asset('metronic/plugins/global/plugins.bundle.js')}}"></script>
    <script src="{{asset('metronic/js/scripts.bundle.js')}}"></script>
    <!--end::Global Javascript Bundle-->
    <!--begin::Page Vendors Javascript(used by this page)-->
    <script src="{{asset('metronic/plugins/custom/datatables/datatables.bundle.js')}}"></script>
    <!--end::Page Vendors Javascript-->
    <!--begin::Page Custom Javascript(used by this page)-->
    <script src="{{asset('metronic/js/widgets.bundle.js')}}"></script>
    <script src="{{asset('metronic/js/custom/widgets.js')}}"></script>
    <script src="{{asset('metronic/js/custom/apps/chat/chat.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/upgrade-plan.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/create-app.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/offer-a-deal/type.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/offer-a-deal/details.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/offer-a-deal/finance.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/offer-a-deal/complete.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/offer-a-deal/main.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/two-factor-authentication.js')}}"></script>
    <script src="{{asset('custom\toastr\toastr.js')}}"></script>
    <!--end::Page Custom Javascript-->
    <!--end::Javascript-->
    <!-- custom -->
    <!-- <script src="{{asset('custom/font-awesome-6.4/fa-all.min.js')}}"></script> -->
        <!--end::Page Vendors Javascript-->
        <!--begin::Page Custom Javascript(used by this page)-->
    <script src="{{asset('metronic/js/widgets.bundle.js')}}"></script>
    <script src="{{asset('metronic/js/custom/widgets.js')}}"></script>
    <script src="{{asset('metronic/js/custom/apps/chat/chat.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/upgrade-plan.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/create-app.js')}}"></script>
    <script src="{{asset('metronic/js/custom/utilities/modals/users-search.js')}}"></script>